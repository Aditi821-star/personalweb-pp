# Title 
## Image Gallery Website

### No. of Stylesheets :-
- home.css (for index.html)
- about1.css (for about.html)
- hobbies1.css (for hobbies.html)
- contact1.css (for contact.html)


### CSS EXPLANATION OF EACH PAGE ###

I am here to explain the CSS codes of my websites like how I style each and every section or element of this website.

## Explanation of CSS codes of home.css i.e stylesheet of home page :-

```CSS
/* Removing browser's padding & Margins accross the page */
*{
    margin: 0;
    padding: 0;
}

/* Setting header height, fonts and color */
header{
    background-color: black;
    font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
    font-size: 1rem;
    
    
}

/* make the haeder flexbox and align at end  */
nav ul{
    height: 6vh;
    
    display: flex;
    
    justify-content: end;
    position: sticky;
    
}
nav ul li{
    padding: 8px 16px;
    
}
nav ul li a{
    text-decoration: none;
    color: white;
    
}

/* stylling the text to be change the color when cursor hover on it */
ul li a:hover{
    
   
    color:#33ccff;
   
    
}

```

*This part of code is for header. In this, firstly I target Header section and set its background color and fonts. Next I make the <ul> a flexbox. For specification I target it as nav ul and etc. then I give padding to <li> for gappings in the header and by target <a> I changes its color and for removing the underline I make txt decoration none. I use hover attribute for better user experience. When cusor hover on the text the color changes to blue.*


```CSS
/* Design the Heading part of page, adding background img, fonts, height and make it a flexbox */
.box{
    height: 27vh;
    background-image: url(https://hiddenpulse.com/wp-content/uploads/2019/03/Stock-Market-Crash-Media-Hoax.jpg);
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 3rem;
    color: rgb(242, 244, 250);
    font-weight:bolder;
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* adding designs and setups to the left class that is for hello text */
.left{
    background: linear-gradient(to bottom, #66ffff 0%, #3366ff 100%);
    color: black;
    text-align: center;
    height: 8vh;
    font-size: 1.3rem;
}


/* stylling the intro name div */
.aditi{
    background-image: url(https://img.freepik.com/free-vector/halftone-background-with-circles_23-2148907689.jpg);
    color:rgb(247, 247, 184);
    text-align: center;
    height: 9vh;
    font-family: cursive;
    font-weight: bold;
    font-size: 1.8rem;
    padding-left: 24px;

} 


/* stylling and making the container flexbox which is for intro para and image */
.container{
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    background: linear-gradient(to left, #33ccff 0%, #ff66ff 100%);
   
   
    height: 75vh;
    
    
}

/* aligning the intro text */
.name{
    
    width: 41vw;
    height: 39vh;
    margin: 90px 108px;
    
}

/* aligning the intro image */
.right{
   
    margin-inline: auto;
    padding-right: 64px;
    padding-top: 71px;
    height: 300px;
    width: 300px;
}

/* adding font styles in intro para */
.name p{
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    font-size: 1.5rem;
    
}

/* stylling the quote div */
.quote{
    background-image: url(https://miro.medium.com/v2/resize:fit:612/1*jcCklpNUka2BEFnr3hND2w.jpeg);
    color: whitesmoke;
    font-size: 1rem;
    font-family:'Courier New', Courier, monospace;
    font-weight: bold;
    text-align: center;
    height: 10vh;
    padding: 17px;
}

```

*In this part of code, firstly I add styles to heading part of page like I put background images, make it a flexbox and justify the content at center for align center effects. Then I style the hello div by adding colors, fonts style and alignment. For putting intro para and images I make the parent container flexbox named container and sets its height and change the colors. Then I align the text in left and the image in right by justifying the content space between and give some paddings. Then I style the quote div, change the background image, give some paddings and add some font styles.*

```CSS
/* making the about container flexbox and stylling it */
.About{
    display: flex;
    justify-content:space-between;
    flex-wrap: wrap;
    background: linear-gradient(to left, #33ccff 0%, #ff66ff 100%);
    height: 60vh;
}

/* stylling and aligning the about para */
.txt{
    padding: 15px;
    padding-top: 26px;
    height: 40vh;
    width: 45vw;
    margin-right: 47px;
    margin-top: 15px;
    align-items: center;
    
}

/* stylling heading of intro para */
.txt h2{
    font-size: 36px;
    font-weight: bold;
    font-family:cursive;
    margin-left: 180px;
}
.txt p{
    font-size: 1.5rem;
    

}

/* set height and width of image div */
.ab_img{
    margin-top: 30px;
    height: 10vh;
    width: 4vw;
}

/* stylling the about me button  */
.txt h5 button a{
    text-decoration: none;
    color: black;
}
.txt h5 button{
    border-radius: 5px;
    font-size: 18px;
    width: 40vw;
    margin-left: 40px;
    margin-top: 30px;
    cursor: pointer;
    
}
```
*In this part of code, I make the about section of home page more visual appealing. I make the container named About for text and image and by using justify content attribute I put the divs of text and image side by side. By adding some paddings I make its visuals nice. I style the image and para by adding font size, background colors , margins etc. Then I style button of this section, givving some margins, adding fonts and justifying height. I use cursor pointer attribute for better user experience.*

```CSS
/* footer styles */
footer{
    background-color: black;
    color: azure;
    height: 23vh;
}
footer ul li a{
    
    color: white;
}
footer ul li{
    padding: 4px;
}
```

*This part of code shows the stylling of footer. By changing the backgroud color, setting the height and gives some padding to <li>, I can easily style the footer.*


##  Visuals of home.css i.e home page :-
:::image type="content" source="../img/Home page (1).png" alt-text="homepage header":::
:::image type="content" source="../img/Home page (2).png" alt-text="homepg content":::
:::image type="content" source="../img/Home page (3).png" alt-text="homepg footer":::


## Explanation of CSS codes of about1.css i.e stylesheet of About Me page :-

```CSS
/* stylling the heading of goals, setting the background color, fonts styles and alignment */
.h_goals{
    background: linear-gradient(to bottom, #66ffff 0%, #3366ff 100%);
    text-align: center;
    height: 7vh;
    font-family: cursive;
    font-style: italic;
    font-size: 16px;
}

/* making the goals container flexbox and style its colors and heights */
.goals{
    display: flex;
    justify-content: space-between;
    background: linear-gradient(to left, #33ccff 0%, #ff66ff 100%);
    height: 80vh;
}

/* justifying the fonts sizes and styles of goals para */
.p_goals{
    
    height: 38vh;
    width: 42vw;
    font-size: 19px;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    padding: 26px 80px;
   
}

/* aligning the goals image by giving padding */
.img_goals{
   
    padding: 90px 90px;
    
}
```

*As in this the header and footer code will be same and I already explain this above. In about me page, I make two sections one for heading and style same as home page and second section for main content. Then I make various divs to add content like my goals, archeivements, likes etc. The above code shows how I design goals div. Firstly, I add heading of div and style it by adding colours , changing styles, setting height etc. then I make a flexbox named goals and inside it I Make seperated div for para and image then I style it according to the requirements.*

##  Visuals of about.html i.e about me page :-

:::image type="content" source="../img/about (1).png" alt-text="about me pg header":::
:::image type="content" source="../img/about (2).png" alt-text="about me pg content":::
:::image type="content" source="../img/about (3).png" alt-text="about me pg footer":::


## Explanation of CSS codes of hobbies1.css i.e stylesheet of Hobbies page :-

```CSS
/* setting the height and styles the fonts of intro para */
.intro_p{
    font-size: 21px;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    background: linear-gradient(to left, #33ccff 0%, #ff66ff 100%);
   text-align: center;
   height: 15vh;
   padding-top: 15px;
}

/* making the container flexbox for images and style its colors */
.intro_img{
    display: flex;
    justify-content: space-between;
    height: 57vh;
    background: linear-gradient(to left, #33ccff 0%, #ff66ff 100%);

}

/* aligning the image */
.img1{
    padding-top: 35px;
    padding-left: 25px;
}
.img2{
     padding-top: 35px;
}
.img3{
    padding-top: 35px;
}
.img4{
    padding-top: 35px;
    padding-right: 25px;
}

/* stylling the heading of hooby1, justifying its colors and fonts styles */
.h_hobby1{
    background: linear-gradient(to bottom, #66ffff 0%, #3366ff 100%);
    text-align: center;
    height: 6vh;
    font-family: cursive;
    font-style: italic;
    font-size: 16px;
}

/* stylling the para of hobby1 including colors, fonts style and height */
.p_hobby1{
    background: linear-gradient(to left, #33ccff 0%, #ff66ff 100%);
    text-align: center;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    font-size: 21px;
    height: 18vh;
    padding-top: 25px;
}

/* making the container flexbox and style the backgrounds and sets sizes */
.img_hobby1{
    display: flex;
    justify-content: space-between;
    height: 65vh;
    background: linear-gradient(to left, #33ccff 0%, #ff66ff 100%);
}

/* aligning the images */
.img1_hobby1{
    padding-top: 20px;
    padding-left: 210px;
    
}
.img2_hobby1{
    padding-top: 20px;
    padding-right: 210px;
}
```

*As in this the header and footer code will be same and I already explain this above. The quote and greetings sections are also be the same. In the hobbies page of my website, I firstly created the <div> for intro para and by setting its width&height, changing the colors and stylling some fonts. Then I make Flexbox for images and align the image seperataly by giving some paddings. In this page I would add details about my four hobbies, the code shows the backend of my first hobby and else are almost same. In the stylling of hobby1, I make the div for para and align it according to requiements. Then I make the flexbox for images of hobby1 and then adding some colors, fonts styllings, changing background colors and setting heights.*

##  Visuals of hobbies.html i.e hobbies page :-

:::image type="content" source="../img/hobbies (1).png" alt-text="hobbies pg header":::
:::image type="content" source="../img/hobbies (2).png" alt-text="hobbies pg content":::
:::image type="content" source="../img/hobbies (3).png" alt-text="hobbies pg footer":::


## Explanation of CSS codes of contact1.css i.e stylesheet of contact me page :-

```CSS
/* making the form container flexbox and justifying ts height and background images */
.form-container{
  background-image: url(https://media.istockphoto.com/id/1311934969/photo/contact-us.jpg?s=612x612&w=0&k=20&c=_vmYyAX0aFi-sHH8eYS-tLLNfs1ZWXnNB8M7_KWwhgg=);
  background-repeat: no-repeat;
  background-size: cover;
    height: 90vh;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
}

/* making the box flex and decrese the transparency for better visuals */
.box{
    background-color: rgba(0, 0, 0, 0.249);
    width: 50vw;
    height: 70vh;
    padding-top: 20px;
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    margin: auto 293px;
    
}

/* stylling the form and align it by padding and margin */
form{
    font-size: 30px;
    font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    color: white;
    padding: 30px 70px ;
    width: 20vw;
    margin-right: 263px;
}

/* aligning the form label */
form label{
    padding: 10px 127px 10px 0px;
}

/* aligning and stylling the form input */
form input{
    width: 20vw;
    height: 5vh;
    border-radius: 10px;
   
   margin-top: 4px;
    font-size: 12px;
    padding-left: 5px;
    
}

/* stylling reset button */
#reset{
    margin-top: 35px;
    margin-right: 10px;
    cursor: pointer;
    border-radius: 5px ;
    background: linear-gradient(to top left, #66ffff 0%, #66ff99 100%);
}

/* stylling submit button */
#submit{
    margin-top: 35px;
    cursor: pointer;
    border-radius: 5px ;
    background: linear-gradient(to top left, #66ffff 0%, #66ff99 100%);
   
}

```
*As in this the header and footer code will be same and I already explain this above. In contact page, I make the form for communication. Firstly I make the form container a flexbox and sets background image for better looks.. Then I make the box div and choose the background color with less transparency and inside it I make the form. I styled the form by givving paddings, fonts sizes, and colors. I give some paddings to labels and also sets the width and paddings of inputs. I style the submit and reset button, set the background colors and many more.*

##  Visuals of hobbies.html i.e hobbies page :-

:::image type="content" source="../img/contact (1).png" alt-text="contact pg header":::
:::image type="content" source="../img/contact (2).png" alt-text="contact pg form":::
:::image type="content" source="../img/contact (3).png" alt-text="contact pg footer":::