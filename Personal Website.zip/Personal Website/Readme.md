# Title
## Personal Website

This website is entirely about me in which you found My intro, hobbies and etc. In this I also include contact me page so that anyone can contact me in which I include <form> tag and many more. I am here to explain the codes of this website and functionality of this web.

## Navigation pages of this website  :-

- Home Page 
- About me
- Hobbies
- Contact me


# Explanation Of codes of index.html i.e. Home page

```html
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
     <!-- Link for adding external CSS -->
    <link rel="stylesheet" href="/css/home.css">
    <link rel="stylesheet" href="/Responsive/phone.css">
    
   

</head>

<body>
    <!-- This is for header including all navigation links across different pages -->
    <header>
        <nav>
            <div class="links">

                <span>
                    <ul>
                        <!-- list with anchor tag for navigation -->
                        <li><a href="index.html">Home</a></li>
                        <li><a href="about.html">About</a></li>
                        <li><a href="hobbies.html">Hobbies</a></li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </span>
               
            </div>


        </nav>

    </header>


```

In this part of code, firstly we intialize that this is a html document. Using Vs code emmet abbrevation we can easily generate the meta code by ! mark. I add external css for stylling and to make it responsive. This code is all about to add header, including all navigation links inside the <nav> tag.
Add <ul> to give header a structure.

```html
<!-- main content of website -->
    <main>
        <!-- heading of the page -->
        <section class="box">
            <H1>HOME</H1>
        </section>
        <!-- content -->
        <section class="intro">
            <!-- div for hello -->
            <div class="left">

                <h1>👋 HELLO!</h1>
            </div>
            <!-- div for intro -->
            <div class="aditi">
                <h3> I'm ADITI</h3>
            </div>
            <!-- parent container for intro para and img -->
            <div class="container">
                <!-- div for intro para -->
                <div class="name">

                    <p>Greetings! I'm Aditi Kumari, a passionate trader and enthusiastic innovator presenting my
                        experiences and insights before you. I'm here to inspire you by my incredible approaches where
                        cretivity meets innovation. Come, let's embark the knowledge, flashes the thoughts and boost
                        your mind to think something new. My aim is to create a mindset that passion aspiration dreams
                        says and ultimetely meets to purpose innovation and growth. Hoping my web engage and motivates
                        you that you can do anything at any age only by your determination. </p>

                </div>
                <!-- div for image for aligning it in right -->
                <div class="right">
                    <img src="https://i.pinimg.com/736x/66/73/e6/6673e6046f3fabeba925f7545db3fd3b.jpg" width="300"
                        height="300" style="border-radius: 70px;" alt="my img">

                </div>
            </div>

```

*This is the main content section of my page. In this I make two sections, one for haeding of the page and second for content. I use various <div> tag to add content like greetings, intro, para and images. I make a conatainer for intro para and images. I want to place it side by side and this i fulfil using CSS.  I also use some inline style in images like border radius and height etc.*

```html
 <!-- parent container for about me para and image -->
            <div class="About">
                <!-- div for about image -->
                <div class="ab_img">
                    <img src="https://wallpapers.com/images/hd/trading-wallpaper-ynfqhj74ml8p96ca.jpg"
                        style="margin-left: 91px; margin-top: 48px; border-radius: 10px;" width="350px" alt="About me">
                </div>
                <!-- div for about para -->
                <div class="txt">
                    <h2>About Me</h2><br>

                    <p>Hi Friends, I am a passionate trader with a relentless drive to continuously learn, adapt, and
                        improve my skills.
                        With a deep fascination for the world of finance and a keen eye for market trends,
                        I have dedicated myself to mastering the art of trading.

                    </p><br>
                    <!-- button for navigate to about me page -->
                    <h5><button class="about1"><a href="about.html">About Me</a></button></h5>
                </div>

            </div>

```
*In this part of code, I make parent container for about me text and images and same things I done in hobbies and contact sections. In this I make a div for image and use inline style in <img> tag with alt attriute. I make a div for about me para and also add a button to navigate on about me page.*

```html
<!-- footer -->
    <footer>
        <center>
            <h5>@My website</h5>
        </center>
        <!-- unordered list -->
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="hobbies.html">Hobbies</a></li>
            <li><a href="contact.html">Contact</a></li>
        </ul>

    </footer>
```
*This is the code for footer in which I add <h5> tag to add some text realated to web and I use <ul> tag to make a list of footer links. By using <a> tag I connect the different page of my website to navigate easily.*



# Explanation Of codes of about.html i.e. About me page

```html
  <!-- heading of archievements section -->
            <div class="h_ar">
                <h2>My Archeivements</h2>
            </div>
            <!-- div for archeivements para -->
            <div class="p_ar">
                
                        I have successfully executed my first trade in the beginning of 2024. <br>
                      Received the Best Student Award for outstanding performance, particularly in academic
                            achievements. <br>
                        Enthusiascally shared that I received the award for the best fiction story in the school
                            magazine. <br>
                       
                       Achieved First position in Zonal level Spell bee competition. <br>
                        Achieved Second position in on the spot poster making competition. <br>
                        I volunteered at the Earth Day tree planting event in Central Park. <br>
                        
                    Achieved First rank in Model making competition on Scientific innovation
                   
               
            </div>
             <!-- parent container for skills image -->
            <div class="skills">
                <!-- image for archievements -->
                <div class="ar_img1">
                    <img src="https://images.squarespace-cdn.com/content/v1/61cccdf24b15db3d8a4a4d3c/1701785951463-U4V4R65T8S7NAMGQUA4I/Novel+Writing.jpg"
                        width="350" height="350" alt="Fiction Story" style="border-radius: 50px;">
                </div>
                <div class="ar_img2">
                    <img src="https://tiimg.tistatic.com/fp/1/001/976/science-model-838.jpg" width="350" height="350"
                        alt="Model" style="border-radius: 50px;">
                </div>
                <div class="ar_img3">
                    <img src="https://i.ytimg.com/vi/86PJFOXSvyI/hqdefault.jpg" width="350" height="350" alt="Poster"
                        style="border-radius: 50px;">
                </div>
            </div>
```

*As in this the header and footer code will be same and I already explain this above. In the about me page I add various information about me like goals, archievements and my likes, skills etc. In every part I add some images, para or list. This part of code is of my archievemnet section. In this I make a <div> for heading and another <div> for para. I make parent container for images named skills, I add three divs in it including tha images and add some inline styles to the images.*


# Explanation Of codes of hobbies.html i.e. Hobbies page

```html
<!-- div for quote -->
            <div class="quote">
                <p>Hobbies are key to unleashing our inner passion and creativity.</p>
                <p>***Austin Mahone***</p>
            </div>
            <!-- div for hobbies intro para  -->
            <div class="intro_p">
                <p>Hey Guys! I am here to showcase my hobbies that gives me sense of balance and fulfillment
                    but also help me to develop interesting skill like creativity, problem solving and time management.
                    This encourages me that life is not just about academical marks, persuing passion and interest
                    develops personal growth and
                    pushes me to learn new things. Let's look forward and learn together!
                </p>
            </div>
            <!-- container for hobbies intro images -->
            <div class="intro_img">
                <!-- div for img1 -->
                <div class="img1">
                    <img src="https://cdn.pixabay.com/photo/2016/12/13/22/15/chart-1905225_640.jpg" width="250"
                        height="250" style="border-radius: 40px;" alt="hobby1">
                </div>
                <!-- div for img2 -->
                <div class="img2">
                    <img src="https://i.pinimg.com/736x/6a/ad/b3/6aadb37ed624a22ee34bef7201693cef.jpg" width="250"
                        height="250" style="border-radius: 40px;" alt="hobby2">
                </div>
                <!-- div for img3 -->
                <div class="img3">
                    <img src="https://cdn.pixabay.com/photo/2016/05/31/23/21/badminton-1428046_1280.jpg" width="250"
                        height="250" style="border-radius: 40px;" alt="hobby3">
                </div>
                <!-- div for img4 -->
                <div class="img4">
                    <img src="https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg" width="250" height="250"
                        style="border-radius: 40px;" alt="hobby4">
                </div>
            </div>

```
*As in this the header and footer code will be same and I already explain this above. In the hobbies page of website,  I add my four hobbies and in each I make <div> for haedings, paragraphs and iamges same as about me page. This part of code shows intro version of my hobbies page, after hello div I make a div for quote and div for intro para in which I use <p> tag for text. I make a parent container for images, inside it I make four divs for images and also add some styles like size borders etc.*


# Explanation Of codes of contact.html i.e. Contact me page

```html
<section class="content">
            <!-- quote -->
            <div class="quote">
                <h3>Let's create, connect and learn together!</h3>
            </div>
            <!-- div for intro para -->
            <div class="p">
                <p> I'm excited to discuss how I can help you or answer any questions you may have. Please fill out the
                    form below, and I'll get back to you as soon as possible. I look forward to connecting with you!"
                </p>
            </div>

            <!-- parent container for form -->
            <div class="form-container">
                <div class="box">
                    <!-- form for contact me -->
                    <form>
                        <table>
                            <tr>
                                <!-- label -->
                                <td><label for="name">Name</label></td>
                                <!-- text input -->
                                <td><input type="text" placeholder="Your Name" id="n"></td>
                            </tr>
                            <tr>
                                <td><label for="email">Email</label></td>
                                <!-- email input -->
                                <td><input type="email" id="e" placeholder="Your Email"></td>
                            </tr>
                            <tr>
                                <td><label for="contact no.">Contact</label></td>
                                <!-- number input -->
                                <td><input type="number" placeholder="Your Contact no." id="c"></td>
                            </tr>
                            <tr>
                                <td><label for="message">Message</label></td>
                                <!-- text input -->
                                <td><input type="text" id="m" placeholder="Feedback or any questions"></td><br>

                            </tr>
                            <tr>
                                <!-- reset input -->
                                <td><input type="reset" id="reset"></td>
                                <!-- submit input -->
                                <td><input type="submit" id="submit"></td>


                            </tr>


                        </table>
                    </form>

                </div>
            </div>
```

*As in this the header and footer code will be same and I already explain this above. In this contact me page, I put form, text and some images for better visuals. After the scetion of heading, I add div for quote and another div for intro para. Then I make a parent container for form and inside it I make a div for box which I style by using CSS. using <table> tag for better alignment and using <label> tag I put the question of form and by using <input> tag I make the txt fields. I clarify the type of input like text, number or email for better user experience.*


```html
<!-- div for call and mail info -->
            <div class="social">
                <div class="call">
                    <center><img src="https://cdn-icons-png.freepik.com/256/126/126523.png?semt=ais_hybrid" width="20"
                            alt="call"></center>
                    <p>1234567890</p>
                </div>
                <div class="mail">
                    <center><img src="https://www.freeiconspng.com/thumbs/email-icon/iconmonstr-email-4-icon-27.png"
                            width="25" alt="email"></center>
                    <p>02@example.com</p>
                </div>


            </div>
```
*In the contact page, I add call and mail image..for give them icon look I add inline style and set their size smaller. I make a parent container for these two logo and text named social. Then I make separate divs for call icon and text & mail icon and text.*